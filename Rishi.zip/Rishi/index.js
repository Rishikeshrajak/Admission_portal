var app = angular.module('myapp',[]);
app.controller('mycontroller',function($scope){
    $scope.users = [
        {"name":"satya prakash nandy","contact":"7979884785","dob":"1998/12/22"},
        {"name":"Rahul Kumar","contact":"7979884785","dob":"1997/12/23"},
        {"name":"Aslam Malik","contact":"7979884785","dob":"1996/12/24"},
        {"name":"Rajan Panda","contact":"7979884785","dob":"1996/12/25"},
        {"name":"Abishek Purty","contact":"7979884785","dob":"1996/12/26"},
        {"name":"Zishan Ahmad","contact":"7979884785","dob":"1996/12/27"},
        {"name":"Ravi Kumar","contact":"7979884785","dob":"1996/12/28"},
        {"name":"Lakshamn Prashad","contact":"7979884785","dob":"1996/12/29"}
    ];
    $scope.birthday_boy = [];
    var date = new Date();
    angular.forEach($scope.users,function(user){
        var arr = user.dob.split("/");
        if((arr[1]==(date.getMonth()+1))&&(arr[2]==date.getDate()))
        {
            $scope.birthday_boy.push(user);
        }
    });
    console.log($scope.birthday_boy);
})